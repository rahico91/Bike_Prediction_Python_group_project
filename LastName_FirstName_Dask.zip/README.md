# Advanced_Python_Individual

Washington DC Biking data

## Libraries

- dask
- dask ml
- seaborn
- gplearn
- pep8
- astral
- plotly
- xgboost


Note: You can find updated env file is in the repo

## To install to environment

`conda install --name intro_python seaborn`


### Please note that the graphs can be seen in the HTML 